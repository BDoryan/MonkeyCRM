<?php
    if(!$_SESSION["account"]["admin"]){
        header("location: manager.php?section=no_access");
    }

    /**
     * - Création de compte
     * - Suppression de compte (demande de confirmation)
     * - Modification de compte
     * - Recherche de compte
     */    
?>
<div class="px-5 pt-2">
    <h2 class="mb-0">Gestionnaire de comptes</h2>
    <p>Afin de pouvoir utiliser Monkey CRM, vous devez disposer d'un compte, grâce à ce gestionnaire vous pouvez créer, supprimer et modifier les comptes actuels</p>
    <hr>
    <div class="pt-3 d-flex justify-content-between align-items-center">
        <h4>Liste des comptes</h4>
        <div>
            <form class="d-flex flex-row mb-0" action="">
                <div class="input-group flex-nowrap">
                    <input name="account_name" type="text" class="form-control" placeholder="Nom de compte" aria-label="Username" aria-describedby="addon-wrapping">
                </div>
                <button type="submit" class="ms-3 btn btn-outline-primary">Rechercher</a>
            </form>
        </div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createAccount">Créer un nouveau compte</button>
    </div>
    <hr>
    <span style="display: none;" id="error" class="text-danger fs-5"><i class="bi-exclamation-circle-fill"></i> Impossible de récupérer la liste des comptes</span>
    <div id="loading" class="d-flex flex-row p-2 m-4">
        <div class="spinner-border text-primary text-center" role="status">
        </div>
        <span class="ps-3 fs-5 text-primary">Chargement de la liste des comptes</span>
    </div>
    <ul id="accounts" class="list-group">
    </ul>
    <div class="modal fade" id="createAccount" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="createAccountLabel" aria-hidden="true">
        <form method="POST" id="create-account" class="modal-dialog needs-validation" novalidate>
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createAccountLabel">Création d'un nouveau compte</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-0">
                <class class="row">
                    <div class="row g-3 mt-0">
                        <div class="col-6">
                        <label for="username" class="form-label">Nom d'utilisateur</label>
                            <div class="input-group has-validation">
                                <input type="text" class="form-control" id="name" placeholder="Benoit CASTRILLO" required="">
                                <div class="invalid-feedback">
                                    Le nom d'utilisateur est obligatoire
                                </div>
                            </div>
                        </div>

                        <div class="col-6">
                            <label for="address" class="form-label">Rôles</label>
                            <input type="text" class="form-control" id="roles" placeholder="Technicien, Commercial"  required>
                            <div class="invalid-feedback">
                                Veuillez définir au moins un rôle
                            </div>
                        </div>

                        <div class="col-12">
                        <label for="email" class="form-label">Adresse email</label>
                        <input type="email" class="form-control" id="email" placeholder="prenom.nom@gmail.com"  required>
                            <div class="invalid-feedback">
                                L'adresse email est obligatoire
                            </div>
                        </div>

                        <div class="col-12">
                            <label for="password" class="form-label">Mot de passe</label>
                            <input type="password" class="form-control" id="password"  required>
                            <div class="invalid-feedback">
                                Veuillez définir le mot de passe
                            </div>
                        </div>

                        <div class="col-12">
                            <label for="password_confirm" class="form-label">Confirmation du mot de passe</label>
                            <input type="password" class="form-control" id="password_confirm" required>
                            <div class="invalid-feedback">
                                Veuillez confirmer le mot de passe
                            </div>
                        </div>
                        <div class="col-12">
                            <input type="checkbox" class="form-check-input" id="admin">
                            <label class="form-check-label" for="admin">Voulez-vous que ce compte soit administrateur</label>
                        </div>
                    </div>
                </form>
            </div>
            <div style="display: none;" class="alert mx-2 mt-2 p-1">
                <p id="alert-message" class="text-center"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                <button type="submit" class="btn btn-primary">Créer le nouveau compte</button>
            </div>
            </div>
        </form>
    </div>
    <!-- Modification de compte -->
    <div class="modal fade" id="editAccount" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editAccountLabel" aria-hidden="true">
        <form method="POST" id="edit-account" class="modal-dialog needs-validation" novalidate>
            <input type="text" class="hide" id="account_id"></input>
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editAccountLabel">Modification du compte</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-0">
                <class class="row">
                    <div class="row g-3 mt-0">
                        <div class="col-6">
                        <label for="username" class="form-label">Nom d'utilisateur</label>
                            <div class="input-group has-validation">
                                <input type="text" class="form-control" id="name" placeholder="Benoit CASTRILLO">
                                <div class="invalid-feedback">
                                    Le nom d'utilisateur est obligatoire
                                </div>
                            </div>
                        </div>

                        <div class="col-6">
                            <label for="address" class="form-label">Rôles</label>
                            <input type="text" class="form-control" id="roles" placeholder="Technicien, Commercial">
                            <div class="invalid-feedback">
                                Veuillez définir au moins un rôle
                            </div>
                        </div>

                        <div class="col-12">
                        <label for="email" class="form-label">Adresse email</label>
                        <input type="email" class="form-control" id="email" placeholder="prenom.nom@gmail.com">
                            <div class="invalid-feedback">
                                L'adresse email est obligatoire
                            </div>
                        </div>

                        <div class="col-12">
                            <label for="password" class="form-label">Mot de passe</label>
                            <input type="password" class="form-control" id="password">
                            <div class="invalid-feedback">
                                Veuillez définir le mot de passe
                            </div>
                        </div>

                        <div class="col-12">
                            <label for="password_confirm" class="form-label">Confirmation du mot de passe</label>
                            <input type="password" class="form-control" id="password_confirm">
                            <div class="invalid-feedback">
                                Veuillez confirmer le mot de passe
                            </div>
                        </div>
                        <div class="col-12">
                            <input type="checkbox" class="form-check-input" id="admin">
                            <label class="form-check-label" for="admin">Voulez-vous que ce compte soit administrateur</label>
                        </div>
                    </div>
                </form>
            </div>
            <div style="display: none;" class="alert mx-2 mt-2 p-1">
                <p id="alert-message" class="text-center"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                <button type="submit" class="btn btn-primary">Modifier le compte</button>
            </div>
            </div>
        </form>
    </div>
    <!-- Suppression de compte -->
    <div class="modal fade" id="deleteAccount" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="createAccountLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createAccountLabel">Confirmation de la suppression du compte</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pt-2">
                <p class="text-danger">Vous devez prendre conscience que lorsque vous aurez confirmer la suppression de ce compte, les données d'un compte seront supprimé, par contre les contacts, les entreprises et les affaires seront stocker dans nos base de donnée mais le compte ne sera plus lié.</p>
                <strong class="pt-2">Voulez-vous vraiment supprimer le compte '<span id="name"></span>' ?</strong>
            </div>
            <div style="display: none;" class="alert mx-2 mt-2 p-1">
                <p id="alert-message" class="text-center"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Annuler</button>
                <button onClick="confirmDelete();" class="btn btn-danger">Confirmer la suppression</button>
            </div>
            </div>
        </form>
    </div>
    <script src="js/accounts.js">
    </script>
</div>