<?php
    $rs = $db->prepare('SELECT * FROM accounts');
    $rs->execute();
    $data = $rs->fetchAll();
?>
<div class="px-5 pt-2">
    <h2 class="mb-0">Paramètre de votre compte</h2>
    <p>Vous avez la possibilité de changer des détails de votre compte, comme le mot de passe, nom d'utilisateur mais aussi votre adresse email. Ces modifications auront aucun impacte sur le fonctionnement de votre compte si ce n'est l'authentification</p>
    <hr>

</div>