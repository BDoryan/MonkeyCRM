<div class="p-5">

<div class="alert alert-danger">
    <h5>Vous n'êtes pas autoriser à accéder à cette page</h5>
    <hr>
    <p>Vous avez essayé d'aller sur une section dont vous n'avez pas les accès, celle-ci est réservé uniquement aux utilisateurs étant administrateur</p>
    <strong>Si cela n'est pas normal, contacter le gérant de votre site internet.</strong>
</div>
</div>
