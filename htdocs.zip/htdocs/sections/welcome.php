
    <div class=" px-4 my-5 text-center border-bottom">
        <h1 class="display-4 fw-bold">Bienvenue sur Monkey CRM</h1>
        <div class="col-lg-6 mx-auto">
        <p class="lead mb-4">Gérer la relation client ou la gestion des relations avec la clientèle, vous retrouverez l'ensemble des outils et techniques destinés à tenir compte des souhaits et des attentes des clients et des prospects, afin de les satisfaire et de les fidéliser en leur offrant ou proposant des services.</p>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-center mb-5">
            <a href="?section=home" class="btn btn-primary btn-lg px-4 me-sm-3">Commencer</a>
            <a type="button" class="btn btn-outline-secondary btn-lg px-4" href="#readmore">Lire la suite</a>
        </div>
        </div>
        <div class="overflow-hidden" style="max-height: 30vh;">
        <div class="container px-5">
            <img src="imgs/monkey-crm.png" class="img-fluid border rounded-3 shadow-lg mb-4" alt="Example image" loading="lazy" width="700" height="500">
        </div>
        </div>
    </div>
    <div class="divider"></div>
    <div id="readmore" class="container px-4 py-5">
        <h2 class="pb-2 mb-2 text-uppercase text-center fw-bolder"><i class="bi-tools text-primary"></i> Nos outils <i class="bi-tools text-primary"></i> </h2>
        <hr>
        <div class="row g-4 py-2 row-cols-1 row-cols-lg-3">
        <div class="feature col">
            <div class="feature-icon bg-primary bg-gradient">
                <i class="bi-person-lines-fill"></i>
            </div>
            <h2>Gérer vos contacts</h2>
            <hr>
            <p>Retrouver tout vos client depuis votre espace contact, grâce à celui-ci vous pourrez suivre les affaires en cours, mais aussi de savoir depuis quel date vous travaillez ensemble, vous avez la possiblité de faire des commentaires et de leurs laisser des avis.</p>
        </div>
        <div class="feature col">
            <div class="feature-icon bg-primary bg-gradient">
                <i class="bi-briefcase-fill"></i>
            </div>
            <h2>Gérer vos affaire</h2>
            <hr>
            <p>Le gestionnaire des affaires est un élément majeur de votre relation client, à l'aide de celle-ci vous allez pouvoir d'éffectuer des démarches afin de proposer des offres. Vous aurez la possibilité de suivre l'état de celle-ci et d'avoir un historique de toute la procédure.</p>
        </div>
        <div class="feature col">
            <div class="feature-icon bg-primary bg-gradient">
                <i class="bi-bar-chart-line-fill"></i>
            </div>
            <h2>Statistiques</h2>
            <hr>
            <p>Le système de statistiques est utilisé sur plusieurs outils, on le retrouve sur les affaires (avec le nombre de propostions faite, nombre d'avis positif, etc) mais aussi vous réalisez des statistiques personnels, votre nombre de contact, le nombre de nouveau contact sur le mois et bien d'autres.</p>
        </div>
    </div>
</div>
    <div class="divider"></div>