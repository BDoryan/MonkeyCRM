class MonkeyAPI {

    static searchAccount(name){

    }

    static deleteAccount(id, response){
        var data = new FormData();
        data.append("id", id);

        MonkeyAPI.sendPostRequest("/actions/delete-account.php", data, response);
    }

    static createAccount(name, email, roles, password, admin, response){
        var data = new FormData();
        data.append("name", name);
        data.append("roles", roles);
        data.append("email", email);
        data.append("password", password);
        data.append("admin", admin);

        MonkeyAPI.sendPostRequest("/actions/create-account.php", data, response);
    }
    
    static editAccount(id, name, email, roles, admin, response){
        MonkeyAPI.editAccount(id, name, email, roles, null, admin, response);
    }

    static editAccount(id, name, email, roles, password, admin, response){
        var data = new FormData();
        data.append("id", id);
        data.append("name", name);
        data.append("roles", roles);
        data.append("email", email);
        if(password != null)
            data.append("password", password);
        data.append("admin", admin);

        MonkeyAPI.sendPostRequest("/actions/edit-account.php", data, response);
    }

    static listAccounts(response) {
        MonkeyAPI.sendPostRequest("/actions/list-accounts.php", null, response);
    }

    static sendPostRequest(url, dataForm, response){
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (this.readyState != 4) {
                return;
            }

            if (this.status == 200) {
                var data = JSON.parse(this.responseText);
                
                console.log(this.responseText);
                console.log(data);

                response(data);
            } else {
                response(null);
            }
        };

        xhr.open('POST', url, true);
        if(dataForm != null) {
            xhr.send(dataForm);
        } else {
            xhr.send();
        }
    }
}