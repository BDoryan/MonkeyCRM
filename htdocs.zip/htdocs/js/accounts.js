
$( document ).ready(function() {
    listAccounts();
});

(function () {
'use strict'

var forms = document.querySelectorAll('.needs-validation')

Array.prototype.slice.call(forms)
    .forEach(function (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
                    
            var jqForm = $(form);
            
            jqForm.find("input").each(function (){
                var input = $(this);
                input.get(0).setCustomValidity("");
            });

            if(jqForm.find("#password").val() != jqForm.find("#password_confirm").val()){
                var error = "Les mot de passes ne sont pas à l'identique.";
                jqForm.find("#password_confirm").parent().find(".invalid-feedback").text(error);
                jqForm.find("#password_confirm").get(0).setCustomValidity(error);
            } else {
                jqForm.find("#password_confirm").get(0).setCustomValidity("");
            }
            if (!form.checkValidity()) {
                event.stopPropagation()
            } else {
                switch (form.id) {
                    case "create-account":
                        createAccount(form);
                        break;
                    case "edit-account":
                        console.log("edit");
                        editAccount(form);
                        break;
                    default:
                        break;
                }
            }

            form.checkValidity();

            form.classList.add('was-validated') 
        }, false)
    })
})
();

function createAccount(form) {
    form = $(form);

    var name = form.find("#name").val();
    var roles = form.find("#roles").val();
    var email = form.find("#email").val();
    var password = form.find("#password").val();
    var admin = form.find("#admin").is(":checked") ? "true" : "false";

    MonkeyAPI.createAccount(name, email, roles, password, admin, function(data) {
        alert = form.find(".alert");
        alert.hide();

        alert.removeClass("alert-success");
        alert.removeClass("alert-danger");
        
        alert.addClass("alert-"+data.type);

        if(data.type == "success"){
            data.reason = "Le compte à été créer avec succès.";

            listAccounts();
        } else {
            if(data.for != "alert-message"){
                form.find("#"+data.for).parent().find(".invalid-feedback").text(data.reason);
                form.find("#"+data.for).get(0).setCustomValidity(data.reason);
            }
        }

        if(data.type == "success" || data.for == "alert-message"){
            alert.show();
            alert.find("#alert-message").text(data.reason);
        }
    });
}

var target_id = -1;
var deleteModal = $("#deleteAccount");
var editModal = $("#editAccount");

var editForm = $("#edit-account");

function showModalEditAccount(id, name, email, roles, admin) {
    target_id = id;
    
    editForm.find("#account_id").val(id);
    editForm.find("#name").val(name);
    editForm.find("#roles").val(roles);
    editForm.find("#email").val(email);
    editForm.find("#admin").prop("checked", admin);

    alert = editForm.find(".alert");
    alert.hide();
    
    editForm.removeClass("was-validated");
    editForm.find("#password").val("");
    editForm.find("#password_confirm").val("");

    editModal.modal('show');
}

function editAccount(form) {
    form = $(form);

    var id = form.find("#account_id").val();
    var name = form.find("#name").val();
    var roles = form.find("#roles").val();
    var email = form.find("#email").val();
    var password = form.find("#password").val();
    var admin = form.find("#admin").is(":checked") ? "true" : "false";

    MonkeyAPI.editAccount(id, name, email, roles, password == "" ? null : password, admin, function(data) {
        alert = form.find(".alert");
        alert.hide();

        alert.removeClass("alert-success");
        alert.removeClass("alert-danger");
        
        alert.addClass("alert-"+data.type);

        if(data.type == "success"){
            data.reason = "Le compte à été modifier avec succès.";

            listAccounts();
        } else {
            if(data.for != "alert-message"){
                form.find("#"+data.for).parent().find(".invalid-feedback").text(data.reason);
                form.find("#"+data.for).get(0).setCustomValidity(data.reason);
            }
        }

        if(data.type == "success" || data.for == "alert-message"){
            alert.show();
            alert.find("#alert-message").text(data.reason);
        }
    });
}

function deleteAccount(id, name) {
    target_id = id;

    editModal.modal('show');
    deleteModal.find("#name").text(name);
}

function confirmDelete(){
    MonkeyAPI.deleteAccount(target_id, function(data) {
        alert = deleteModal.find(".alert");
        alert.hide();

        alert.removeClass("alert-success");
        alert.removeClass("alert-danger");
        
        alert.addClass("alert-"+data.type);

        if(data.type == "success"){
            deleteModal.modal('hide');
            listAccounts();
        } else {
            alert.show();
            alert.find("#alert-message").text(data.reason);
            }
    });
}

function listAccounts() {
    MonkeyAPI.listAccounts(function(data) {
        let container = $("#accounts");
        container.html("");

        let loading = $("#loading");
        loading.show();

        let error = $("#error");
        error.hide();

        let accounts = data.type == "success" ? data.data : null;
        if(accounts != null){
            for (let accounts_size = 0; accounts_size < accounts.length; accounts_size++) {
                const account = accounts[accounts_size];

                let div = document.createElement("li");
                div.classList.add("list-group-item","d-flex", "justify-content-between", "align-items-center");
                div.innerHTML = `
                    <div class="d-flex flex-row">
                        <img src="https://github.com/mdo.png" alt="" class="rounded-circle me-2" width="80" height="80">
                        <div class="d-flex flex-column">
                            <h4 class="text-dark mb-0" id="name">`+account.name+`</h4>
                            <p class="text-dark mb-0" id="email">`+account.email+`</p>
                            <div class="d-flex flex-row" id="roles">
                            </div>
                        </div>
                    </div>
                    <div class="d-flex flex-column">
                        <button type="button" onClick="showModalEditAccount(`+account.id+`, '`+account.name+`', '`+account.email+`', '`+account.roles+`', `+account.admin+`)" class="btn btn-outline-secondary">Modifier</a>
                        <button type="button" onClick="deleteAccount(`+account.id+`, '`+account.name+`')" class="btn btn-danger mt-1">Supprimer</button>
                    </div>
                `;

                div = $(div);
                div.find("#name").text(account.name);
                div.find("#email").text(account.email);

                let rolesElement = div.find("#roles");
                
                let roles = account.roles.replace(" ", "").split(",");
                if(account.admin){
                    rolesElement.append(`<span class="badge bg-danger mb-0 me-2">Administrateur</span>`)
                }
                for (let roles_count = 0; roles_count < roles.length; roles_count++) {
                    const role = roles[roles_count];

                    rolesElement.append(`<span class="badge bg-primary mb-0 me-2">`+role+`</span>`)
                }

                container.append(div);
            }
        } else {
            error.show();
        }

        loading.addClass("hide");
    });
}