<?php
    require_once "commons/main.php";

    if(!isset($_SESSION["account"])){
        header("location: index.php?reason=not_logged");
    }
?>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">

    <script src="js/monkeycrm-api.js"></script>

    <title>Monkey CRM - Gestionnaire</title>
  </head>
    <body>
            
        <?php 
            if(isset($_GET["section"])){
                $section = $_GET["section"];
            } else {
                $section = "welcome";
            }
            $path = "sections/".$section.".php";
            
                
            if(!file_exists($path)){
                $section = null;
            }
        ?>
        
        <div class="d-flex">
            <main>
                <div class="sidebar d-flex flex-column px-3 py-2 bg-light shadow-lg">
                    <div class="d-flex justify-content-center">
                        <a href="?section=welcome" class="d-flex flex-column justify-content-center text-center text-decoration-none text-dark">
                            <img src="imgs/logo.webp" class="mx-auto d-block" width="100">
                            <span class="fs-4">Money CRM</span>
                            <p>Gestionnaire de relation client</p>
                        </a>
                    </div>
                    <hr>
                    <ul class="nav nav-pills flex-column mb-auto">
                        <li class="nav-item">
                            <a href="?section=home" class="nav-link <?php if(strcasecmp($section, "home") == 0) { echo "active"; } ?>">
                            <i class="bi bi-house-fill"></i>
                            Accueil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="?section=dashboard" class="nav-link <?php if(strcasecmp($section, "dashboard") == 0) { echo "active"; } ?>">
                                <i class="bi bi-speedometer"></i>
                            Tableau de bord
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="?section=contacts"  class="nav-link <?php if(strcasecmp($section, "contacts") == 0) { echo "active"; } ?>">
                                <i class="bi bi-person-lines-fill"></i>
                            Contacts
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="?section=buisness" class="nav-link <?php if(strcasecmp($section, "buisness") == 0) { echo "active"; } ?>">
                                <i class="bi bi-briefcase-fill"></i>
                            Affaires
                            </a>
                        </li>
                        <?php
                                if( $_SESSION["account"]["admin"]):
                            ?>
                        <hr>
                        <li class="nav-item">
                            <a href="?section=accounts" class="nav-link <?php if(strcasecmp($section, "accounts") == 0) { echo "active"; } ?>">
                                <i class="bi bi-gear-fill"></i>
                            Comptes
                            </a>
                        </li>
                        <?php endif;?>
                    </ul>
                    <hr>  
                    <div class="align-self-center d-flex flex-shrink-0 flex-row mb-2">
                        <img src="https://github.com/mdo.png" alt="" class="rounded-circle me-2" width="80" height="80">
                        <div>
                            <h4 class="text-dark mb-0"><?php echo $_SESSION["account"]["name"] ?></h4>
                            <p class="text-dark mb-0"><?php echo $_SESSION["account"]["email"] ?></p>
                            <?php
                                if( $_SESSION["account"]["admin"]):
                            ?>
                            <span class="badge bg-danger mb-0">Administrateur</span>
                            <?php
                                endif;
                                foreach ($_SESSION["account"]["roles"] as $role):
                            ?>
                            <span class="badge bg-primary mb-0"><?php echo $role?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <a type="button" href="?section=settings" class="btn btn-outline-primary w-100 mb-1">
                        <i class="bi bi-gear-fill px-1"></i>Paramètres</a>
                    <a href="disconnect.php" class="btn btn-danger w-100">
                        <i class="bi bi-door-open-fill px-1"></i>Déconnexion</a>
                </div> 
            </main>
        </div>
        <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <div class="manager-container pt-5">
            <?php if(is_null($section)): ?>
                <div class="mb-auto text-center text-danger p-5">
                    <h3>Erreur 404</h3>
                    <p>Nous sommes désolé, mais cette page est introuvable</p>
                </div>
            <?php else: 
                    include("sections/".$section.".php");
                endif;
            ?>
        </div>
  </body>
</html>