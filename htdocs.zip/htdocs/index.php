<?php
    require_once 'commons/main.php';

    if(isset($_POST) && count($_POST) > 0 && isset($_POST["name"]) && isset($_POST["password"])){
        $name = htmlspecialchars($_POST["name"]);
        $password = htmlspecialchars($_POST["password"]);

        $check = $db->prepare('SELECT id, name, roles, email, admin, password FROM accounts WHERE name = ?');
        $check->execute(array($name));
        $data = $check->fetch();

        $row = $check->rowCount();


        if($row == 1){
            if(password_verify($password, $data["password"])){
                $roles = explode(",", $data["roles"]);
                $_SESSION["account"] = array("id" => $data["id"], "name" => $data["name"], "email" => $data["email"], "password" => $data["password"], "admin" => $data["admin"], "roles" => $roles);
                header("location: manager.php");
            } else {
                $error = "Ces identifiants sont incorrecte.";
            }
        } else {
            $error = "Ces identifiants sont incorrecte.";
        }
    } else if (isset($_POST) && count($_POST) > 0) {
        $error = "Veuillez saisir complêtement les identifiants.";
    }
    
    if(isset($_GET["reason"])){
        switch($_GET["reason"]){
            case "not_logged":
                $error = "Votre session est invalide ou à expirée, veuillez vous reconnecter.";
            break;
            case "disconnect":
                $error = "Vous vous êtes déconnecté de votre compte.";
            break;
            case "password_change":
                $error = "Votre session n'est plus valide, vous identifiant de connexion on était changé.";
            break;
        }
    }
?>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">

    <title>Monkey CRM - Bienvenue</title>
  </head>
  <body class="d-flex flex-column bg-light-2">
        <header class="navbar bg-light text-dark px-3 d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 navbar-bg border-bottom">
            <a href="/" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none">
                <img src="imgs/logo.webp" class="me-2" width="64" height="64">
                <h3 class="mb-0">Monkey CRM</h3></p>
            </a>

            <div class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                <img src="imgs/ixeo.webp">
            </div>
        <!--
        <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
            <li><a href="#" class="nav-link px-2 link-secondary">Accueil</a></li>
            <li><a href="#" class="nav-link px-2 link-dark">Présentation</a></li>
            <li><a href="#" class="nav-link px-2 link-dark">FAQs</a></li>
            <li><a href="#" class="nav-link px-2 link-dark">Contactez</a></li>
        </ul>
        -->

            <div class="col-md-3 text-end">
                <a type="button" class="btn btn-outline-primary me-2">En savoir plus</a>
            </div>
        </header>
        <div class="row justify-content-md-center rounded m-0 my-4 px-5">
            <div class="text-center col-md-6 pt-5 bg-light text-dark shadow-lg">
                <div>
                    <img src="imgs/logo.webp" class="me-2" height="100">
                    <h3 class="pt-3 mb-0">Monkey CRM</h3>
                    <p>Gestionnaire de la relation client</p>
                </div>
                <div class="mx-5 d-flex flex-column text-start">
                <hr>
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger">
                        <p class="mb-0"><?php echo $error; ?></p>
                    </div>
                <?php endif; ?>
                <form class="pt-3 d-flex flex-column" action="index.php" method="post">
                    <div class="mb-3">
                        <label for="recipient-name" class="col-form-label">Nom de compte:</label>
                        <input name="name" type="text" class="form-control" required id="name">
                    </div>
                    <div class="mb-3">
                        <label for="message-text" class="col-form-label">Mot de passe:</label>
                        <input name="password" type="password" required class="form-control" id="password"></input>
                    </div>
                <button type="submit" class="align-self-center btn btn-success mb-2" data-bs-toggle="modal" data-bs-target="#signin">Se connecté à mon compte</button>
                </form>
                </div>
                <div class="pt-5">
                    <img src="imgs/ixeo.webp" class="bi me-2">
                </div>
            <p class="pt-5 text-center">Développé par <a href="http://doryanbessiere.fr">Doryan BESSIERE</a> pour <a href="https://ixeo.fr">IXEO</a></p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
  </body>
</html>