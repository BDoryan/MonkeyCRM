<?php
    require_once 'commons/main.php';

    $_SESSION["account"] = null;

    header("location: index.php?reason=disconnect");