<?php
    require_once '../commons/main.php';

    $response;

    if(isset($_SESSION["account"])){
        try {
            $rs = $db->prepare('SELECT id, name, email, roles, admin FROM accounts');
            $rs->execute();
            $data = $rs->fetchAll();

            $response = array("type" => "success", "data" => $data);
        } catch (Exception $e){
            $response = array("type" => "danger", "for" => "alert-message", "reason" => "Erreur lors de l'envoi de la requête : ".$e->getMessage());
        }
    } else {
        $response = array("type" => "danger", "for" => "alert-message", "reason" => "Votre session à expirée.");
    }
            
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($response);