<?php
    require_once '../commons/main.php';

    $response;

    if(isset($_SESSION["account"])){
        if(isset($_POST) && count($_POST) > 0 && isset($_POST["id"])){
            $id = $_POST["id"];

            try {
                $check = $db->prepare('DELETE FROM accounts WHERE id = ?');
                $check->execute(array($id));

                $response = array("type" => "success");
            } catch (Exception $e){
                $response = array("type" => "danger", "for" => "alert-message", "reason" => "Erreur lors de l'envoi de la requête : ".$e->getMessage());
            }
        } else {
            $response = array("type" => "danger", "for" => "alert-message", "reason" => "Veuillez remplir complêtement le formulaire.");
        }
    } else {
        $response = array("type" => "danger", "for" => "alert-message", "reason" => "Votre session à expirée.");
    }
            
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($response);