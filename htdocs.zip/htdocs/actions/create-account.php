<?php
    require_once '../commons/main.php';

    $response;

    if(isset($_SESSION["account"])){
        if(isset($_POST) && count($_POST) > 0 && isset($_POST["name"]) && isset($_POST["email"]) && isset($_POST["admin"]) && isset($_POST["roles"]) && isset($_POST["password"])){
            $name = $_POST["name"];

            $check = $db->prepare('SELECT id FROM accounts WHERE name = ?');
            $check->execute(array($name));
            $data = $check->fetch();

            $row = $check->rowCount();

            if($row == 0){
                try {
                    $check = $db->prepare("INSERT INTO accounts (`name`, `email`, `password`, `roles`, `admin`) VALUES ('".$name."', '".$_POST["email"]."', '".password_hash($_POST["password"], PASSWORD_BCRYPT)."', '".$_POST["roles"]."', '".$_POST["admin"]."')");
                    $check->execute();

                    $response = array("type" => "success");
                } catch (Exception $e){
                    $response = array("type" => "danger", "for" => "alert-message", "reason" => "Erreur lors de l'envoi de la requête : ".$e->getMessage());
                }
            } else {
                $response = array("type" => "danger", "for" => "name", "reason" => "Ce nom d'utilisateur est déjà utilisé.");
            }
        } else {
            $response = array("type" => "danger", "for" => "alert-message", "reason" => "Veuillez remplir complêtement le formulaire.");
        }
    } else {
        $response = array("type" => "danger", "for" => "alert-message", "reason" => "Votre session à expirée.");
    }
            
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($response);