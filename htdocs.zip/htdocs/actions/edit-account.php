<?php
    require_once '../commons/main.php';

    $response;
    
    if(isset($_SESSION["account"])){
        if(isset($_POST) && count($_POST) > 0 && isset($_POST["id"]) && isset($_POST["name"]) && isset($_POST["email"]) && isset($_POST["admin"]) && isset($_POST["roles"])){
            $id = $_POST["id"];
            $name = $_POST["name"];
            $email = $_POST["email"];
            $roles = $_POST["roles"];
            $admin = $_POST["admin"];
            $password = isset($_POST["password"]) ? $_POST["password"] : null;

            $check = $db->prepare('SELECT id FROM accounts WHERE name = ?');
            $check->execute(array($name));
            $data = $check->fetch();

            $row = $check->rowCount();

            if($row == 0 || $data["id"] == $id){
                try {
                    $request = "UPDATE accounts SET `name`='".$name."', `email`='".$email."', ".(isset($password) ? "`password`='".password_hash($password, PASSWORD_BCRYPT)."', " : "")."`roles`='".$roles."', `admin`=".$admin.", `last_update`=CURRENT_TIMESTAMP WHERE id = ?";
                    $check = $db->prepare($request);
                    $check->execute(array($id));

                    $response = array("type" => "success");
                } catch (Exception $e){
                    $response = array("type" => "danger", "for" => "alert-message", "reason" => "Erreur lors de l'envoi de la requête : ".$e->getMessage());
                }
            } else {
                $response = array("type" => "danger", "for" => "name", "reason" => "Ce nom d'utilisateur est déjà utilisé.");
            }
        } else {
            $response = array("type" => "danger", "for" => "alert-message", "reason" => "Veuillez remplir complêtement le formulaire.");
        }
    } else {
        $response = array("type" => "danger", "for" => "alert-message", "reason" => "Votre session à expirée.");
    }
            
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($response);