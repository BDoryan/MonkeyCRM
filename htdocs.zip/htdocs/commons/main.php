<?php
    require_once 'database.php';
    require_once 'check-session.php';
