<?php
    session_start();

    if(isset($_SESSION) && isset($_SESSION["account"])){
        $account  = $_SESSION["account"];
    
        $check = $db->prepare('SELECT id, name, email, roles, password, admin FROM accounts WHERE id = ?');
        $check->execute(array($account["id"]));
        $data = $check->fetch();
    
        $row = $check->rowCount();

        if($row > 0){
            if($account["password"] != $data["password"]){
                echo $account["password"];
                echo $data["password"];
                $_SESSION["account"] = null;
            } else {
                $roles = explode(",", $data["roles"]);
                $_SESSION["account"] = array(
                    "id" => $data["id"], 
                    "name" => $data["name"], 
                    "email" => $data["email"], 
                    "password" => $data["password"], 
                    "admin" => $data["admin"], 
                    "roles" => $roles
                );
            }
        } else {
            $_SESSION["account"] = null;
        }
    }