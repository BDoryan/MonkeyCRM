<?php

$address = "localhost";
$username = "root";
$password = "";
$database = "monkeycrm";

try {
    $db = new PDO("mysql:host=".$address.";dbname=".$database.";charset=utf8", $username, $password);
} catch (Exception $e){
    die("Erreur : ".$e->getMessage());
}